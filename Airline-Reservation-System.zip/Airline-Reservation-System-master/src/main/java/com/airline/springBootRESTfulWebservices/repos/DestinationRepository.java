package com.airline.springBootRESTfulWebservices.repos;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.airline.springBootRESTfulWebservices.models.Destination;

@Repository
public interface DestinationRepository extends CrudRepository<Destination, Integer> {
}
