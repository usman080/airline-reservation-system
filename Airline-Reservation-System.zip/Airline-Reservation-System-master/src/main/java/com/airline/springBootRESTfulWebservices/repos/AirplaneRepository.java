package com.airline.springBootRESTfulWebservices.repos;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.airline.springBootRESTfulWebservices.models.Airplane;

@Repository
public interface AirplaneRepository extends CrudRepository<Airplane, Integer> {
}
