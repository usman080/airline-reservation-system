package com.airline.springBootRESTfulWebservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRESTfulWebservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRESTfulWebservicesApplication.class, args);
	}

}
